const allSongs = [
    {
        id: 1,
        name: "Ram siya Ram",
        artist: "Artist 1",
        img: "Assets/images/ram.jpg", // Replace with the actual image filename or URL
        genre: "Pop",
        source: "Assets/music/ram.mp3", // Replace with the actual audio source file
    },
    {
        id: 2,
        name: "Song 2",
        artist: "Artist 2",
        img: "song2.jpg", // Replace with the actual image filename or URL
        genre: "Rock",
        source: "song2.mp3", // Replace with the actual audio source file
    },
    {
        id: 3,
        name: "Song 3",
        artist: "Artist 3",
        img: "song3.jpg", // Replace with the actual image filename or URL
        genre: "Hip Hop",
        source: "song3.mp3", // Replace with the actual audio source file
    },
    {
        id: 4,
        name: "Song 4",
        artist: "Artist 1",
        img: "song1.jpg", // Replace with the actual image filename or URL
        genre: "Rock",
        source: "song1.mp3", // Replace with the actual audio source file
    },
    {
        id: 5,
        name: "Song 5",
        artist: "Artist 2",
        img: "song2.jpg", // Replace with the actual image filename or URL
        genre: "Rock",
        source: "song2.mp3", // Replace with the actual audio source file
    },
    {
        id: 6,
        name: "Song 6",
        artist: "Artist 3",
        img: "song3.jpg", // Replace with the actual image filename or URL
        genre: "Pop",
        source: "song3.mp3", // Replace with the actual audio source file
    },
    // Add more songs as needed
];

const filterGenre = document.getElementById("filter-genre");
const songList = document.getElementById("song-list");
const imageCard = document.getElementById("image-card");
const audioPlayer = document.getElementById("audio-player");
const Card = document.getElementById("card");
const musicplayer = document.getElementById("musicplayer");
const nextButton = document.getElementById("nextButton");
const previous = document.getElementById("previous");
const playlistSection = document.getElementById("playlist-section");
const playlistNameInput = document.getElementById("playlist-name");
const createPlaylistButton = document.getElementById("createplaylist");

let currentSongIndex = 0;


// Extract unique genres from the allSongs array
const uniqueGenres = [...new Set(allSongs.map((song) => song.genre))];
// Create and append options for each unique genre
uniqueGenres.forEach((genre) => {
    const option = document.createElement("option");
    option.value = genre;
    option.textContent = genre;
    filterGenre.appendChild(option);
});
filterGenre.addEventListener("click", displayFilterSong);

function displayFilterSong() {
    const selectedGenre = filterGenre.value;
    const filteredSongs = allSongs.filter((song) => song.genre === selectedGenre);
    // Display filtered songs
    renderSongs(filteredSongs);
}
// Initial display of songs based on the default selected genre


function renderSongs(songs) {
    songList.innerHTML = ""; // Clear previous content

    songs.forEach((song) => {
        const songDiv = document.createElement("button");
        songDiv.className = "song-card";
        songDiv.id = song.id;
        songDiv.innerHTML = `<h3>${song.name}</h3>`;
        songList.appendChild(songDiv);
        songDiv.addEventListener("click", () => {
            playSong(song);
        });
    });
    function playSong(song) {
        // create a contains title
        const title = document.getElementById("title");
        title.innerHTML = song.name;
        // create a Artist-title-
        const ArtistTitle = document.getElementById("Artist-title");
        ArtistTitle.innerHTML = song.artist;
        // craete a image card
        const image = document.createElement("img");
        image.src = song.img;
        image.alt = song.name;
        imageCard.innerHTML = ""; // Clear previous content
        imageCard.appendChild(image);
        musicplayer.innerHTML = `<source src=${song.source}>`;
    }
    function playNextSong() {
        currentSongIndex = (currentSongIndex + 1) % allSongs.length;
        playSong(allSongs[currentSongIndex])
    }
    
    function playPreviousSong() {
        currentSongIndex = (currentSongIndex - 1 + allSongs.length) % allSongs.length;
        playSong(allSongs[currentSongIndex])
    }
    nextButton.addEventListener("click", playNextSong);
    previous.addEventListener("click", playPreviousSong);
}

// ... (previous code remains unchanged)

createPlaylistButton.addEventListener('click', createplaylist);
let playlists = []; 
function createplaylist(e) {
    e.preventDefault();
    const playlistName = playlistNameInput.value.trim();
    if (playlistName !== "") {
        const newPlaylist = {
            name: playlistName,
            songs: allSongs.slice(), // Copy all songs to the new playlist
        };
        playlists.push(newPlaylist);
        playlistNameInput.value = '';
        // Display the created playlist in the playlist section
        
        displayPlaylists();
    } else {
        // Display an error message if the playlist name is empty
        alert("Please enter a valid playlist name.");
    }
}
function displayPlaylists() {
    // Clear previous content in the playlist section
    playlistSection.innerHTML = "";
   

    // Display each playlist in the playlist section
    playlists.forEach((playlist) => {
        const playlistDiv = document.createElement("div");
        playlistDiv.className = "playlist";
        playlistDiv.innerHTML = `<h3>${playlist.name}</h3>`;
        playlistSection.appendChild(playlistDiv);
    });
}
// Get the theme-toggle checkbox and store it in a variable
// const themeToggleCheckbox = document.getElementById("theme-toggle");

// Add an event listener to detect changes in the checkbox
let isDarkMode = false;

function toggleColors() {
    const body = document.body;
    isDarkMode = !isDarkMode;

    if (isDarkMode) {
        body.classList.add('dark-mode');
    } else {
        body.classList.remove('dark-mode');
    }
}





